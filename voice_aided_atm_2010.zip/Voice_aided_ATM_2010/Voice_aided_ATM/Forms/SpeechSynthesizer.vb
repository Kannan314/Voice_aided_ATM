﻿
Class SpeechSynthesizer

End Class
